import {StationTimes} from 'src/app/model/StationTimes'

export interface Respose
{
    times: StationTimes[]
}