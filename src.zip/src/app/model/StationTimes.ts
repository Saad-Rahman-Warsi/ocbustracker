import { DirTime } from "./Dirtime";

export interface StationTimes
{
    stationLabel:String;
    station:number;
    times:DirTime[];
}