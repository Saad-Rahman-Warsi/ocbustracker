export interface DirTime
{
    direction:String;
    time:number;
    route:number;
}